package com.mopot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MopotApplication {

	public static void main(String[] args) {
		SpringApplication.run(MopotApplication.class, args);
	}

}
